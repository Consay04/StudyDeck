# StudyDeck — Study Planner Dashboard

A dark-mode dashboard to manage **subjects, tasks and deadlines**, with a built-in **focus timer** that logs study time.

**Stack:** Express.js (backend) · SQLite via better-sqlite3 (database) · Vanilla HTML/CSS/JS (frontend)

## Features
- Full CRUD for **subjects** and **tasks** (create, read, update, delete)
- Live dashboard stats: completion %, overdue tasks, due this week, study streak
- Per-subject progress bars and weekly study-hour goals
- Focus timer that saves sessions and feeds a 7-day chart
- Filters by status and subject; overdue highlighting

## Run it
```bash
npm install
npm start
```
Open http://localhost:3000. The SQLite file (`study.db`) is created automatically with sample data.

## API
| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | `/api/subjects` | List / create subjects |
| PUT/DELETE | `/api/subjects/:id` | Update / delete a subject |
| GET/POST | `/api/tasks` | List / create tasks |
| PUT/DELETE | `/api/tasks/:id` | Update / delete a task |
| POST | `/api/sessions` | Log a focus session |
| GET | `/api/stats` | Dashboard statistics |
